#
import xbmc
import xbmcaddon
import os
import subprocess

__scriptname__ = "InternetPVR"
__author__     = "lsellens"
__url__        = "http://code.google.com/p/repository-lsellens/"
__selfpath__   = xbmcaddon.Addon(id='script.module.internetpvr').getAddonInfo('path')

#try to get service addon info or send notification to install it.
try:
    __addon__      = xbmcaddon.Addon(id='script.service.internetpvr')
    __addonpath__  = __addon__.getAddonInfo('path')
    __start__      = xbmc.translatePath(__addonpath__ + '/resources/audo.py')
except:
    xbmc.executebuiltin("XBMC.Notification('InternetPVR', 'Install InternetPVR service!', '30000', %s)" % ( __selfpath__ + '/icon.png'))
    xbmc.log('InternetPVR: Could not detect service addon:', level=xbmc.LOGERROR)
    exit()

#try to get Transmission service addon info.
try:
    __txaddon__      = xbmcaddon.Addon(id='service.downloadmanager.transmission')
    __txaddonpath__  = __txaddon__.getAddonInfo('path')
    __txstop__       = xbmc.translatePath(__txaddonpath__ + '/bin/transmission.stop')
    __txstart__      = xbmc.translatePath(__txaddonpath__ + '/transmissionstart.py')
except:
    xbmc.executebuiltin("XBMC.Notification('InternetPVR', 'Install Transmission service!', '30000', %s)" % ( __selfpath__ + '/icon.png'))
    xbmc.log('InternetPVR: Could not detect Transmission addon:', level=xbmc.LOGERROR)
    exit()

if __name__ == '__main__':

    # Shutdown audo
    os.system("kill `ps | grep -E 'python.*script.module.audo' | awk '{print $1}'`")

    # Shutdown Transmission
    subprocess.Popen(__txstop__, shell=True, close_fds=True)

    #Open settings dialog
    __addon__.openSettings()

    # Restart audo
    try:
        xbmc.executebuiltin('XBMC.RunScript(%s)' % __start__, True)
    except Exception, e:
        xbmc.log('InternetPVR: Could not execute InternetPVR launch script:', level=xbmc.LOGERROR)
        xbmc.log(str(e), level=xbmc.LOGERROR)

    # Restart Transmission
    try:
        xbmc.executebuiltin('XBMC.RunScript(%s)' % __txstart__, True)
    except Exception, e:
        xbmc.log('InternetPVR: Could not execute Transmission launch script:', level=xbmc.LOGERROR)
        xbmc.log(str(e), level=xbmc.LOGERROR)
