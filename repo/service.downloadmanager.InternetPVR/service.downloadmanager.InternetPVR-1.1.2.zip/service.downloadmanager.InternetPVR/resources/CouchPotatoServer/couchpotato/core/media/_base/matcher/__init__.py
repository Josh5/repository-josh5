from .main import Matcher


def autoload():
    return Matcher()

config = []
