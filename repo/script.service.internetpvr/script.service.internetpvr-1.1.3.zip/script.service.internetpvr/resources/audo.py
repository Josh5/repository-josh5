# Initializes and launches SABnzbd, Couchpotato, Sickbeard and Headphones
from xml.dom.minidom import parseString
from configobj import ConfigObj
import subprocess
import urllib2
import hashlib
import xbmc
import xbmcaddon
import xbmcvfs

import time
import xbmcgui
import sys
import socket
import fcntl
import struct
import os

# helper functions
# ----------------


def check_connection():
        ifaces = ['eth0','eth1','wlan0','wlan1','wlan2','wlan3']
        connected = []
        i = 0
        for ifname in ifaces:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                socket.inet_ntoa(fcntl.ioctl(
                        s.fileno(),
                        0x8915,  # SIOCGIFADDR
                        struct.pack('256s', ifname[:15])
                )[20:24])
                connected.append(ifname)
                print "%s is connected" % ifname
            except:
                print "%s is not connected" % ifname
            i += 1
        return connected

def media_link(link, dest):
    print "Checking for location: "+link
    rm = "rm "+link
    ln = "ln -s "+dest+" "+link
    if not os.path.exists(link):
        subprocess.check_output(ln, shell=True)
	print "Not Found! Creating: "+link
    elif os.path.exists(link):
	print "Link Already Found!"
        subprocess.check_output(rm, shell=True)
	print "Removing: "+link
        subprocess.check_output(ln, shell=True)
	print "Creating: "+link

def create_dir(dirname):
    if not xbmcvfs.exists(dirname):
        xbmcvfs.mkdirs(dirname)
        xbmc.log('InternetPVR: Created directory ' + dirname, level=xbmc.LOGDEBUG)

# define some things that we're gonna need, mainly paths
# ------------------------------------------------------

#Get host IP:
connected_ifaces = check_connection()
if len(connected_ifaces) == 0:
    print 'not connected to any network'
    hostIP = "on Port"
else:
    GetIP = ([(s.connect(('8.8.8.8', 80)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1])
    hostIP = ' on '+GetIP
    print hostIP

#Create Strings for notifications:
started   = 'Service started'+hostIP
waiting   = 'Looking for Media download folders...'
disabled  = 'Service disabled for this session'
restarted = 'Service restarted'+hostIP
SAport  = ':8081'
SBport  = ':8082'
CPport  = ':8083'
HPport  = ':8084'

# addon
__addon__             = xbmcaddon.Addon(id='script.service.internetpvr')
__addonpath__         = xbmc.translatePath(__addon__.getAddonInfo('path'))
__addonhome__         = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__addonname__         = __addon__.getAddonInfo('name')
__icon__              = __addon__.getAddonInfo('icon')
__programs__          = xbmc.translatePath(xbmcaddon.Addon(id='script.module.audo-programs').getAddonInfo('path'))
__dependancies__      = xbmc.translatePath(xbmcaddon.Addon(id='script.module.audo-dependencies').getAddonInfo('path'))

# settings
pDefaultSuiteSettings = xbmc.translatePath(__addonpath__ + '/settings-default.xml')
pSuiteSettings        = xbmc.translatePath(__addonhome__ + 'settings.xml')
pXbmcSettings         = '/root/.xbmc/userdata/guisettings.xml'
pSabNzbdSettings      = xbmc.translatePath(__addonhome__ + 'sabnzbd.ini')
pSickBeardSettings    = xbmc.translatePath(__addonhome__ + 'sickbeard.ini')
pCouchPotatoServerSettings  = xbmc.translatePath(__addonhome__ + 'couchpotatoserver.ini')
pHeadphonesSettings   = xbmc.translatePath(__addonhome__ + 'headphones.ini')


# Read add-on settings
# --------------------
# Transmission-Daemon
transauth = False
try:
    transmissionaddon = xbmcaddon.Addon(id='service.downloadmanager.transmission')
    transauth = (transmissionaddon.getSetting('TRANSMISSION_AUTH').lower() == 'true')
    transdl = (transmissionaddon.getSetting('TRANSMISSION_DL_DIR').decode('utf-8'))
    transinc = (transmissionaddon.getSetting('TRANSMISSION_INC_DIR').decode('utf-8'))
    transwatch = (transmissionaddon.getSetting('TRANSMISSION_WATCH_DIR').decode('utf-8'))

    if transauth:
        xbmc.log('InternetPVR: Transmission Authentication Enabled', level=xbmc.LOGDEBUG)
        transuser = (transmissionaddon.getSetting('TRANSMISSION_USER').decode('utf-8'))
        if transuser == '':
            transuser = None
        transpwd = (transmissionaddon.getSetting('TRANSMISSION_PWD').decode('utf-8'))
        if transpwd == '':
            transpwd = None
    else:
        xbmc.log('InternetPVR: Transmission Authentication Not Enabled', level=xbmc.LOGDEBUG)

except Exception, e:
    xbmc.log('InternetPVR: Transmission Settings are not present', level=xbmc.LOGNOTICE)
    xbmc.log(str(e), level=xbmc.LOGNOTICE)
    pass

# InternetPVR
user = (__addon__.getSetting('SABNZBD_USER').decode('utf-8'))
pwd = (__addon__.getSetting('SABNZBD_PWD').decode('utf-8'))
host = (__addon__.getSetting('SABNZBD_IP'))
sabnzbd_launch = (__addon__.getSetting('SABNZBD_LAUNCH').lower() == 'true')
sickbeard_launch = (__addon__.getSetting('SICKBEARD_LAUNCH').lower() == 'true')
couchpotato_launch = (__addon__.getSetting('COUCHPOTATO_LAUNCH').lower() == 'true')
headphones_launch = (__addon__.getSetting('HEADPHONES_LAUNCH').lower() == 'true')

#Define Simple Mode settings
simplemode = (__addon__.getSetting('InternetPVR_MODE').lower() == 'true')
sickbeard_watch_dir = (__addon__.getSetting('TVSHOW_DIR').decode('utf-8'))
couchpotato_watch_dir = (__addon__.getSetting('MOVIES_DIR').decode('utf-8'))
headphones_watch_dir = (__addon__.getSetting('MUSIC_DIR').decode('utf-8'))
dl_dir = (__addon__.getSetting('TRANSMISSION_DL_DIR').decode('utf-8'))

# Set Torrent Downloads directories
pHomeDownloadsDir              = dl_dir
pInternetPVRComplete           = dl_dir + "complete"
pInternetPVRCompleteTV         = dl_dir + "complete/tvshows"
pInternetPVRCompleteMov        = dl_dir + "complete/movies"
pInternetPVRCompleteMus        = dl_dir + "complete/music"

# NZB Downloads directories
pSabNzbdComplete      = dl_dir + 'nzb'
pSabNzbdWatchDir      = dl_dir + 'nzb/watch'
pSabNzbdIncomplete    = dl_dir + 'nzb/incomplete'
pSabNzbdCompleteTV    = dl_dir + 'complete/tvshows'
pSabNzbdCompleteMov   = dl_dir + 'complete/movies'
pSabNzbdCompleteMusic = dl_dir + 'complete/music'
pSickBeardTvScripts   = xbmc.translatePath(__programs__ + '/resources/SickBeard/autoProcessTV')
pSabNzbdScripts       = xbmc.translatePath(__addonhome__ + 'scripts')

# service commands
sabnzbd               = ['python', xbmc.translatePath(__programs__ + '/resources/SABnzbd/SABnzbd.py'),
                         '-d', '-f', pSabNzbdSettings, '-l 0']
sickBeard             = ['python', xbmc.translatePath(__programs__ + '/resources/SickBeard/SickBeard.py'),
                         '--daemon', '--datadir', __addonhome__, '--config', pSickBeardSettings]
couchPotatoServer     = ['python', xbmc.translatePath(__programs__ + '/resources/CouchPotatoServer/CouchPotato.py'),
                         '--daemon', '--pid_file', xbmc.translatePath(__addonhome__ + 'couchpotato.pid'),
                         '--config_file', pCouchPotatoServerSettings]
headphones            = ['python', xbmc.translatePath(__programs__ + '/resources/Headphones/Headphones.py'),
                         '-d', '--datadir', __addonhome__, '--config', pHeadphonesSettings]

# Other stuff
sabNzbdHost           = 'localhost:8081'

# create directories and settings on first launch
# -----------------------------------------------
# First check directories still exist for simple mode
if simplemode:
    dlDIR  = not os.path.exists(pHomeDownloadsDir)
    dialog = xbmcgui.Dialog()
    xbmc.log('InternetPVR: Checking if downloads DIR is writable', level=xbmc.LOGDEBUG)
    while (dlDIR != ""):
        dlDIR  = not os.path.exists(pHomeDownloadsDir)
        if dlDIR:
            promptstart = dialog.yesno(__addonname__, "Could not find your Download directory.", "Check that your location settings are correct.", "[B]Would you like to disable "+__addonname__+" for this session?[/B]")
            if promptstart:
                xbmc.log('InternetPVR: Add-on disabled. Download DIR not found', level=xbmc.LOGDEBUG)
                dialog.ok(__addonname__, __addonname__+" has been disabled for this session", "", "[B]To use "+__addonname__+", restart XBMC[/B]")
                xbmc.executebuiltin('XBMC.Notification('+ __addonname__ +','+ disabled +',5000,'+ __icon__ +')')
                sys.exit("InternetPVR not Started")
            else:
                xbmc.executebuiltin('XBMC.Notification('+ __addonname__ +','+ waiting +',5000,'+ __icon__ +')')
            xbmc.log('InternetPVR: Waiting 20 for download DIR...', level=xbmc.LOGDEBUG)
            time.sleep(20)
        else:
            #xbmc.executebuiltin('XBMC.Notification('+ __addonname__ +','+ started +',5000,'+ __icon__ +')')
            break

firstLaunch = not xbmcvfs.exists(pSabNzbdSettings)
sbfirstLaunch = not xbmcvfs.exists(pSickBeardSettings)
cpfirstLaunch = not xbmcvfs.exists(pCouchPotatoServerSettings)
hpfirstLaunch = not xbmcvfs.exists(pHeadphonesSettings)

xbmc.log('InternetPVR: Creating directories if missing', level=xbmc.LOGDEBUG)
create_dir(__addonhome__)
create_dir(pSabNzbdComplete)
create_dir(pSabNzbdWatchDir)
create_dir(pSabNzbdCompleteTV)
create_dir(pSabNzbdCompleteMov)
create_dir(pSabNzbdCompleteMusic)
create_dir(pSabNzbdIncomplete)
create_dir(pSabNzbdScripts)

create_dir(sickbeard_watch_dir)
create_dir(couchpotato_watch_dir)
create_dir(headphones_watch_dir)
create_dir(pInternetPVRComplete)
create_dir(pInternetPVRCompleteTV)
create_dir(pInternetPVRCompleteMov)
create_dir(pInternetPVRCompleteMus)

if not xbmcvfs.exists(xbmc.translatePath(pSabNzbdScripts + '/sabToSickBeard.py')):
    xbmcvfs.copy(xbmc.translatePath(pSickBeardTvScripts + '/sabToSickBeard.py'), pSabNzbdScripts + '/sabToSickBeard.py')
if not xbmcvfs.exists(xbmc.translatePath(pSabNzbdScripts + '/autoProcessTV.py')):
    xbmcvfs.copy(xbmc.translatePath(pSickBeardTvScripts + '/autoProcessTV.py'), pSabNzbdScripts + '/autoProcessTV.py')

# the settings file already exists if the user set settings before the first launch
if not xbmcvfs.exists(pSuiteSettings):
    xbmcvfs.copy(pDefaultSuiteSettings, pSuiteSettings)

# read XBMC settings
# ----------------------------
# XBMC
fXbmcSettings = open(pXbmcSettings, 'r')
data = fXbmcSettings.read()
fXbmcSettings.close()
xbmcSettings = parseString(data)
xbmcServices = xbmcSettings.getElementsByTagName('services')[0]
xbmcPort         = xbmcServices.getElementsByTagName('webserverport')[0].firstChild.data
try:
    xbmcUser     = xbmcServices.getElementsByTagName('webserverusername')[0].firstChild.data
except StandardError:
    xbmcUser = ''
try:
    xbmcPwd      = xbmcServices.getElementsByTagName('webserverpassword')[0].firstChild.data
except StandardError:
    xbmcPwd = ''

# Edit Transmission:
# -------------------
# Edit Transmission settings.
try:
    __txaddon__      = xbmcaddon.Addon(id='service.downloadmanager.transmission')
    __txaddonpath__  = __txaddon__.getAddonInfo('path')
    __txaddonhome__  = xbmc.translatePath(__txaddon__.getAddonInfo('profile'))
    __txstop__       = xbmc.translatePath(__txaddonpath__ + '/bin/transmission.stop')
    __txstart__      = xbmc.translatePath(__txaddonpath__ + '/transmissionstart.py')
    pTransmission_Addon_Settings  = xbmc.translatePath(__txaddonhome__ + 'settings.xml')
    pTransmission_Settings_New    = xbmc.translatePath(__txaddonhome__ + 'settings2.xml')
    pTransmission_Stop            = xbmc.translatePath(__txaddonpath__ + '/bin/transmission.stop')
    pTransmission_Start           = xbmc.translatePath(__txaddonpath__ + '/transmissionstart.py')

    infile       = open(pTransmission_Addon_Settings)
    outfile      = open(pTransmission_Settings_New, 'w')
    replacements = {transdl:dl_dir+'complete', transinc:dl_dir+'incoming'}

    for line in infile:
        for src, target in replacements.iteritems():
            line = line.replace(src, target)
        outfile.write(line)
    infile.close()
    outfile.close()

    from os import remove
    from shutil import move
    remove(pTransmission_Addon_Settings)
    move(pTransmission_Settings_New, pTransmission_Addon_Settings)

except Exception, e:
    xbmc.log('InternetPVR: Transmission Settings are not present', level=xbmc.LOGNOTICE)
    xbmc.log(str(e), level=xbmc.LOGNOTICE)
    pass

# prepare execution environment
os.environ['PYTHONPATH'] = str(os.environ.get('PYTHONPATH')) + ':' + __dependancies__ + '/lib'

# Execution Services:
# -------------------
# SABnzbd start
try:
    # write SABnzbd settings
    # ----------------------
    sabNzbdConfig = ConfigObj(pSabNzbdSettings, create_empty=True)
    defaultConfig = ConfigObj()
    defaultConfig['misc'] = {}
    defaultConfig['misc']['disable_api_key']   = '0'
    defaultConfig['misc']['check_new_rel']     = '0'
    defaultConfig['misc']['auto_browser']      = '0'
    defaultConfig['misc']['username']          = user
    defaultConfig['misc']['password']          = pwd
    defaultConfig['misc']['port']              = '8081'
    defaultConfig['misc']['https_port']        = '9081'
    defaultConfig['misc']['https_cert']        = 'server.cert'
    defaultConfig['misc']['https_key']         = 'server.key'
    defaultConfig['misc']['host']              = host
    defaultConfig['misc']['web_dir']           = 'Plush'
    defaultConfig['misc']['web_dir2']          = 'Plush'
    defaultConfig['misc']['web_color']         = 'gold'
    defaultConfig['misc']['web_color2']        = 'gold'
    defaultConfig['misc']['log_dir']           = 'logs'
    defaultConfig['misc']['admin_dir']         = 'admin'
    defaultConfig['misc']['nzb_backup_dir']    = 'backup'
    defaultConfig['misc']['script_dir']        = 'scripts'

    if firstLaunch:
        defaultConfig['misc']['download_dir']  = pSabNzbdIncomplete
        defaultConfig['misc']['complete_dir']  = pSabNzbdComplete
        servers = {}
        servers['localhost'] = {}
        servers['localhost']['host']           = 'localhost'
        servers['localhost']['port']           = '119'
        servers['localhost']['enable']         = '0'
        categories = {}
        categories['tv'] = {}
        categories['tv']['name']               = 'tv'
        categories['tv']['script']             = 'sabToSickBeard.py'
        categories['tv']['priority']           = '-100'
        categories['movies'] = {}
        categories['movies']['name']           = 'movies'
        categories['movies']['dir']            = 'movies'
        categories['movies']['priority']       = '-100'
        categories['music'] = {}
        categories['music']['name']            = 'music'
        categories['music']['dir']             = 'music'
        categories['music']['priority']        = '-100'
        defaultConfig['servers'] = servers
        defaultConfig['categories'] = categories

    sabNzbdConfig.merge(defaultConfig)
    sabNzbdConfig.write()

    # also keep the autoProcessTV config up to date
    autoProcessConfig = ConfigObj(xbmc.translatePath(pSabNzbdScripts + '/autoProcessTV.cfg'), create_empty=True)
    defaultConfig = ConfigObj()
    defaultConfig['SickBeard'] = {}
    defaultConfig['SickBeard']['host']         = 'localhost'
    defaultConfig['SickBeard']['port']         = '8082'
    defaultConfig['SickBeard']['username']     = user
    defaultConfig['SickBeard']['password']     = pwd
    autoProcessConfig.merge(defaultConfig)
    autoProcessConfig.write()

    # launch SABnzbd and get the API key
    # ----------------------------------
    if firstLaunch or sabnzbd_launch:
        xbmc.log('InternetPVR: Launching SABnzbd...', level=xbmc.LOGDEBUG)
        subprocess.call(sabnzbd, close_fds=True)
        xbmc.log('InternetPVR: ...done', level=xbmc.LOGDEBUG)
        xbmc.executebuiltin('XBMC.Notification(SABnzbd,'+ started + SAport +',5000,'+ __icon__ +')')

        # SABnzbd will only complete the .ini file when we first access the web interface
        if firstLaunch:
            try:
                if not (user and pwd):
                    urllib2.urlopen('http://' + sabNzbdHost)
                else:
                    urllib2.urlopen('http://' + sabNzbdHost + '/api?mode=queue&output=xml&ma_username=' + user +
                                    '&ma_password=' + pwd)
            except Exception, e:
                xbmc.log('InternetPVR: SABnzbd exception occurred', level=xbmc.LOGERROR)
                xbmc.log(str(e), level=xbmc.LOGERROR)

        sabNzbdConfig.reload()
        sabNzbdApiKey = sabNzbdConfig['misc']['api_key']

        if firstLaunch and not sabnzbd_launch:
            urllib2.urlopen('http://' + sabNzbdHost + '/api?mode=shutdown&apikey=' + sabNzbdApiKey)
            xbmc.log('InternetPVR: Shutting SABnzbd down...', level=xbmc.LOGDEBUG)

except Exception, e:
    xbmc.log('InternetPVR: SABnzbd exception occurred', level=xbmc.LOGERROR)
    xbmc.log(str(e), level=xbmc.LOGERROR)
# SABnzbd end

# SickBeard start
try:
    # write SickBeard settings
    # ------------------------
    sickBeardConfig = ConfigObj(pSickBeardSettings, create_empty=True)
    defaultConfig = ConfigObj()
    defaultConfig['General'] = {}
    defaultConfig['General']['launch_browser'] = '0'
    defaultConfig['General']['version_notify'] = '0'
    defaultConfig['General']['use_api']        = '1'
    defaultConfig['General']['web_port']       = '8082'
    defaultConfig['General']['web_host']       = host
    defaultConfig['General']['web_username']   = user
    defaultConfig['General']['web_password']   = pwd
    defaultConfig['General']['cache_dir']      = __addonhome__ + 'sbcache'
    defaultConfig['General']['log_dir']        = __addonhome__ + 'logs'
    defaultConfig['SABnzbd'] = {}
    defaultConfig['XBMC'] = {}
    defaultConfig['XBMC']['use_xbmc']          = '1'
    defaultConfig['XBMC']['xbmc_host']         = 'localhost:' + xbmcPort
    defaultConfig['XBMC']['xbmc_username']     = xbmcUser
    defaultConfig['XBMC']['xbmc_password']     = xbmcPwd
    defaultConfig['TORRENT'] = {}

    if sabnzbd_launch:
        defaultConfig['SABnzbd']['sab_username']   = user
        defaultConfig['SABnzbd']['sab_password']   = pwd
        defaultConfig['SABnzbd']['sab_apikey']     = sabNzbdApiKey
        defaultConfig['SABnzbd']['sab_host']       = 'http://' + sabNzbdHost + '/'

    if transauth:
        defaultConfig['TORRENT']['torrent_username']         = transuser
        defaultConfig['TORRENT']['torrent_password']         = transpwd
        defaultConfig['TORRENT']['torrent_path']             = pSabNzbdCompleteTV
        defaultConfig['TORRENT']['torrent_host']             = 'http://localhost:9091/'

    if sbfirstLaunch:
        defaultConfig['General']['tv_download_dir']       = pSabNzbdComplete
        defaultConfig['General']['metadata_xbmc_12plus']  = '0|0|0|0|0|0|0|0|0|0'
        defaultConfig['General']['nzb_method']            = 'sabnzbd'
        defaultConfig['General']['keep_processed_dir']    = '0'
        defaultConfig['General']['use_banner']            = '1'
        defaultConfig['General']['rename_episodes']       = '1'
        defaultConfig['General']['naming_ep_name']        = '0'
        defaultConfig['General']['naming_use_periods']    = '1'
        defaultConfig['General']['naming_sep_type']       = '1'
        defaultConfig['General']['naming_ep_type']        = '1'
        defaultConfig['General']['root_dirs']             = '0|/root/tvshows'
        defaultConfig['General']['naming_custom_abd']     = '0'
        defaultConfig['General']['naming_abd_pattern']    = '%SN - %A-D - %EN'
        defaultConfig['Blackhole'] = {}
        defaultConfig['Blackhole']['torrent_dir']         = pSabNzbdWatchDir
        defaultConfig['SABnzbd']['sab_category']          = 'tv'
        # workaround: on first launch, sick beard will always add 
        # 'http://' and trailing '/' on its own
        defaultConfig['SABnzbd']['sab_host']              = sabNzbdHost
        defaultConfig['XBMC']['xbmc_notify_ondownload']   = '1'
        defaultConfig['XBMC']['xbmc_update_library']      = '1'
        defaultConfig['XBMC']['xbmc_update_full']         = '1'

    if simplemode:
        defaultConfig['General']['torrent_method']        = 'transmission'
        defaultConfig['General']['naming_pattern']        = 'Season %0S/%S.N.S%0SE%0E.%Q.N-%RG'
        defaultConfig['General']['process_automatically'] = '1'
        defaultConfig['General']['use_api']               = '1'
        defaultConfig['General']['api_key']               = 'eff2ebc240c91e342e14418874cc7a4f'
        defaultConfig['General']['tv_download_dir']       = pInternetPVRCompleteTV
        defaultConfig['General']['metadata_xbmc_12plus']  = '0|0|0|0|0|0|0|0|0|0'
        defaultConfig['General']['keep_processed_dir']    = '0'
        defaultConfig['General']['use_banner']            = '1'
        defaultConfig['General']['rename_episodes']       = '1'
        defaultConfig['General']['naming_ep_name']        = '0'
        defaultConfig['General']['naming_use_periods']    = '1'
        defaultConfig['General']['naming_sep_type']       = '1'
        defaultConfig['General']['naming_ep_type']        = '1'
        defaultConfig['General']['root_dirs']             = '0|' + sickbeard_watch_dir
        defaultConfig['General']['naming_custom_abd']     = '0'
        defaultConfig['TORRENT']['torrent_path']          = pInternetPVRCompleteTV
        defaultConfig['TORRENT']['torrent_host']          = 'http://localhost:9091/'
        defaultConfig['EZRSS'] = {}
        defaultConfig['EZRSS']['ezrss']                   = '1'
        defaultConfig['KICKASSTORRENTS'] = {}
        defaultConfig['KICKASSTORRENTS']['kickasstorrents'] = '1'
        defaultConfig['THEPIRATEBAY'] = {}
        defaultConfig['THEPIRATEBAY']['thepiratebay']     = '1'
        defaultConfig['XBMC']['xbmc_notify_ondownload']   = '1'
        defaultConfig['XBMC']['xbmc_notify_onsnatch']     = '1'
        defaultConfig['XBMC']['xbmc_update_library']      = '1'
        defaultConfig['XBMC']['xbmc_update_full']         = '1'

    sickBeardConfig.merge(defaultConfig)
    sickBeardConfig.write()

    # launch SickBeard
    # ----------------
    if sickbeard_launch:
        xbmc.log('InternetPVR: Launching SickBeard...', level=xbmc.LOGDEBUG)
        subprocess.call(sickBeard, close_fds=True)
        xbmc.log('InternetPVR: ...done', level=xbmc.LOGDEBUG)
        xbmc.executebuiltin('XBMC.Notification(SickBeard,'+ started + SBport +',5000,'+ __icon__ +')')
except Exception, e:
    xbmc.log('InternetPVR: SickBeard exception occurred', level=xbmc.LOGERROR)
    xbmc.log(str(e), level=xbmc.LOGERROR)
# SickBeard end

# CouchPotatoServer start
try:
    # empty password hack
    if pwd == '':
        md5pwd = ''
    else:
        #convert password to md5
        md5pwd = hashlib.md5(str(pwd)).hexdigest()

    # write CouchPotatoServer settings
    # --------------------------
    couchPotatoServerConfig = ConfigObj(pCouchPotatoServerSettings, create_empty=True, list_values=False)
    defaultConfig = ConfigObj()
    defaultConfig['core'] = {}
    defaultConfig['core']['username']            = user
    defaultConfig['core']['password']            = md5pwd
    defaultConfig['core']['port']                = '8083'
    defaultConfig['core']['launch_browser']      = '0'
    defaultConfig['core']['host']                = host
    defaultConfig['core']['data_dir']            = __addonhome__
    defaultConfig['core']['show_wizard']         = '0'
    defaultConfig['core']['debug']               = '0'
    defaultConfig['core']['development']         = '0'
    defaultConfig['updater'] = {}
    defaultConfig['updater']['enabled']          = '0'
    defaultConfig['updater']['notification']     = '0'
    defaultConfig['updater']['automatic']        = '0'
    defaultConfig['xbmc'] = {}
    defaultConfig['xbmc']['enabled']             = '1'
    defaultConfig['xbmc']['host']                = 'localhost:' + xbmcPort
    defaultConfig['xbmc']['username']            = xbmcUser
    defaultConfig['xbmc']['password']            = xbmcPwd
    defaultConfig['Sabnzbd'] = {}
    defaultConfig['transmission'] = {}

    if sabnzbd_launch:
        defaultConfig['Sabnzbd']['username']     = user
        defaultConfig['Sabnzbd']['password']     = pwd
        defaultConfig['Sabnzbd']['api_key']      = sabNzbdApiKey
        defaultConfig['Sabnzbd']['host']         = sabNzbdHost

    if transauth:
        defaultConfig['transmission']['username']         = transuser
        defaultConfig['transmission']['password']         = transpwd
        defaultConfig['transmission']['directory']        = pSabNzbdCompleteMov
        defaultConfig['transmission']['host']             = 'localhost:9091'

    if cpfirstLaunch:
        defaultConfig['xbmc']['xbmc_update_library']      = '1'
        defaultConfig['xbmc']['xbmc_update_full']         = '1'
        defaultConfig['xbmc']['xbmc_notify_onsnatch']     = '1'
        defaultConfig['xbmc']['xbmc_notify_ondownload']   = '1'
        defaultConfig['xbmc']['on_snatch']                = '1'
        defaultConfig['blackhole'] = {}
        defaultConfig['blackhole']['directory']           = pSabNzbdWatchDir
        defaultConfig['blackhole']['use_for']             = 'both'
        defaultConfig['blackhole']['enabled']             = '0'
        defaultConfig['Sabnzbd']['category']              = 'movies'
        defaultConfig['Sabnzbd']['pp_directory']          = pSabNzbdCompleteMov
        defaultConfig['renamer'] = {}
        defaultConfig['renamer']['enabled']               = '1'
        defaultConfig['renamer']['from']                  = pSabNzbdCompleteMov
        defaultConfig['renamer']['to']                    = '/root/videos'
        defaultConfig['renamer']['separator']             = '.'
        defaultConfig['renamer']['cleanup']               = '0'
        defaultConfig['core']['permission_folder']        = '0644'
        defaultConfig['core']['permission_file']          = '0644'

    if simplemode:
        defaultConfig['xbmc']['xbmc_update_library']      = '1'
        defaultConfig['xbmc']['xbmc_update_full']         = '1'
        defaultConfig['xbmc']['xbmc_notify_onsnatch']     = '1'
        defaultConfig['xbmc']['xbmc_notify_ondownload']   = '1'
        defaultConfig['blackhole'] = {}
        defaultConfig['blackhole']['directory']           = transwatch
        defaultConfig['blackhole']['use_for']             = 'torrent'
        defaultConfig['blackhole']['enabled']             = '0'
        defaultConfig['renamer'] = {}
        defaultConfig['renamer']['enabled']               = '1'
        defaultConfig['renamer']['from']                  = pInternetPVRCompleteMov
        defaultConfig['renamer']['to']                    = couchpotato_watch_dir
        defaultConfig['renamer']['separator']             = '.'
        defaultConfig['renamer']['cleanup']               = '1'
        defaultConfig['renamer']['file_action']           = 'move'
        defaultConfig['renamer']['rename_nfo']            = '0'
        defaultConfig['subtitle'] = {}
        defaultConfig['subtitle']['languages']            = 'en'
        defaultConfig['subtitle']['enabled']              = '1'
        defaultConfig['nzbindex'] = {}
        defaultConfig['nzbindex']['enabled']              = '0'
        defaultConfig['mysterbin'] = {}
        defaultConfig['mysterbin']['enabled']             = '0'
        defaultConfig['core']['api_key']                  = 'f181f1fff3c34ba5bc27b0e1c846cfe4'
        defaultConfig['core']['permission_folder']        = '0644'
        defaultConfig['core']['permission_file']          = '0644'
        defaultConfig['core']['port']                     = '8083'
        defaultConfig['core']['show_wizard']              = '0'
        defaultConfig['core']['launch_browser']           = '0'
        defaultConfig['searcher'] = {}
        defaultConfig['searcher']['preferred_method']     = 'torrent'
        defaultConfig['searcher']['required_words']       = '720p, 1080p'
        defaultConfig['searcher']['preferred_words']      = 'YIFY, x264, BrRip'
        defaultConfig['manage'] = {}
        defaultConfig['manage']['startup_scan']           = '0'
        defaultConfig['manage']['library_refresh_interval'] = '10'
        defaultConfig['manage']['enabled']                = '1'
        defaultConfig['manage']['library']                = couchpotato_watch_dir
        defaultConfig['transmission']['enabled']          = '1'
        defaultConfig['transmission']['directory']        = pInternetPVRCompleteMov
        defaultConfig['transmission']['host']             = 'localhost:9091'
        defaultConfig['newznab'] = {}
        defaultConfig['newznab']['enabled']               = '0'
        defaultConfig['yify'] = {}
        defaultConfig['yify']['enabled']                  = '1'
        defaultConfig['yify']['seed_time']                = '0'
        defaultConfig['yify']['seed_ratio']               = '0'
        defaultConfig['yify']['extra_score']              = '30000'
        defaultConfig['kickasstorrents'] = {}
        defaultConfig['kickasstorrents']['enabled']       = 'True'
        defaultConfig['kickasstorrents']['seed_time']     = '0'
        defaultConfig['kickasstorrents']['seed_ratio']    = '0'
        defaultConfig['torrentz'] = {}
        defaultConfig['torrentz']['enabled']              = 'True'
        defaultConfig['torrentz']['verified_only']        = 'True'
        defaultConfig['torrentz']['seed_time']            = '0'
        defaultConfig['torrentz']['seed_ratio']           = '0'

    couchPotatoServerConfig.merge(defaultConfig)
    couchPotatoServerConfig.write()

    # launch CouchPotatoServer
    # ------------------
    if couchpotato_launch:
        xbmc.log('InternetPVR: Launching CouchPotatoServer...', level=xbmc.LOGDEBUG)
        subprocess.call(couchPotatoServer, close_fds=True)
        xbmc.log('InternetPVR: ...done', level=xbmc.LOGDEBUG)
        xbmc.executebuiltin('XBMC.Notification(CouchPotatoServer,'+ started + CPport +',5000,'+ __icon__ +')')
except Exception, e:
    xbmc.log('InternetPVR: CouchPotatoServer exception occurred', level=xbmc.LOGERROR)
    xbmc.log(str(e), level=xbmc.LOGERROR)
# CouchPotatoServer end

# Headphones start
try:
    # write Headphones settings
    # -------------------------
    headphonesConfig = ConfigObj(pHeadphonesSettings, create_empty=True)
    defaultConfig = ConfigObj()
    defaultConfig['General'] = {}
    defaultConfig['General']['launch_browser']            = '0'
    defaultConfig['General']['api_enabled']               = '1'
    defaultConfig['General']['http_port']                 = '8084'
    defaultConfig['General']['http_host']                 = host
    defaultConfig['General']['http_username']             = user
    defaultConfig['General']['http_password']             = pwd
    defaultConfig['General']['check_github']              = '0'
    defaultConfig['General']['check_github_on_startup']   = '0'
    defaultConfig['General']['cache_dir']                 = __addonhome__ + 'hpcache'
    defaultConfig['General']['log_dir']                   = __addonhome__ + 'logs'
    defaultConfig['XBMC'] = {}
    defaultConfig['XBMC']['xbmc_enabled']                 = '1'
    defaultConfig['XBMC']['xbmc_host']                    = 'localhost:' + xbmcPort
    defaultConfig['XBMC']['xbmc_username']                = xbmcUser
    defaultConfig['XBMC']['xbmc_password']                = xbmcPwd
    defaultConfig['SABnzbd'] = {}
    defaultConfig['Transmission'] = {}

    if sabnzbd_launch:
        defaultConfig['SABnzbd']['sab_apikey']         = sabNzbdApiKey
        defaultConfig['SABnzbd']['sab_host']           = sabNzbdHost
        defaultConfig['SABnzbd']['sab_username']       = user
        defaultConfig['SABnzbd']['sab_password']       = pwd

    if transauth:
        defaultConfig['Transmission']['transmission_username'] = transuser
        defaultConfig['Transmission']['transmission_password'] = transpwd
        defaultConfig['Transmission']['transmission_host']     = 'http://localhost:9091'

    if hpfirstLaunch:
        defaultConfig['SABnzbd']['sab_category']               = 'music'
        defaultConfig['XBMC']['xbmc_update']                   = '1'
        defaultConfig['XBMC']['xbmc_notify']                   = '1'
        defaultConfig['General']['music_dir']                  = '/root/music'
        defaultConfig['General']['destination_dir']            = '/root/music'
        defaultConfig['General']['torrentblackhole_dir']       = pSabNzbdWatchDir
        defaultConfig['General']['download_dir']               = pSabNzbdCompleteMusic
        defaultConfig['General']['move_files']                 = '1'
        defaultConfig['General']['rename_files']               = '1'
        defaultConfig['General']['folder_permissions']         = '0644'

    if simplemode:
        defaultConfig['XBMC']['xbmc_update']                  = '1'
        defaultConfig['XBMC']['xbmc_notify']                  = '1'
        defaultConfig['General']['music_dir']                 = headphones_watch_dir
        defaultConfig['General']['destination_dir']           = headphones_watch_dir
        defaultConfig['General']['prefer_torrents']           = '1'
        defaultConfig['General']['torrentblackhole_dir']      = transwatch
        defaultConfig['General']['download_torrent_dir']      = pInternetPVRCompleteMus
        defaultConfig['General']['move_files']                = '1'
        defaultConfig['General']['rename_files']              = '1'
        defaultConfig['General']['correct_metadata']          = '1'
        defaultConfig['General']['cleanup_files']             = '1'
        defaultConfig['General']['folder_permissions']        = '0644'
        defaultConfig['General']['torrent_downloader']        = '1'
        defaultConfig['General']['api_enabled']               = '1'
        defaultConfig['General']['api_key']                   = 'baf90d3054d3707e2c083d33137ba6eb'
        defaultConfig['General']['move_files']                = '1'
        defaultConfig['General']['piratebay']                 = '1'
        defaultConfig['General']['kat']                       = '1'
        defaultConfig['General']['isohunt']                   = '1'
        defaultConfig['General']['kat']                       = '1'
        defaultConfig['General']['mininova']                  = '1'
        defaultConfig['General']['piratebay']                 = '1'
        defaultConfig['Transmission']['transmission_host']    = 'http://localhost:9091'

    headphonesConfig.merge(defaultConfig)
    headphonesConfig.write()

    # launch Headphones
    # -----------------
    if headphones_launch:
        xbmc.log('InternetPVR: Launching Headphones...', level=xbmc.LOGDEBUG)
        subprocess.call(headphones, close_fds=True)
        xbmc.log('InternetPVR: ...done', level=xbmc.LOGDEBUG)
        xbmc.executebuiltin('XBMC.Notification(Headphones,'+ started + HPport +',5000,'+ __icon__ +')')
except Exception, e:
    xbmc.log('InternetPVR: Headphones exception occurred', level=xbmc.LOGERROR)
    xbmc.log(str(e), level=xbmc.LOGERROR)
# Headphones end

