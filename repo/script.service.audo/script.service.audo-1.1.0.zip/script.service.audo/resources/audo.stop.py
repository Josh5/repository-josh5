#!/usr/bin/env python

import subprocess, signal
import os
import xbmc

p = subprocess.Popen(['ps', '-w'], stdout=subprocess.PIPE)
out, err = p.communicate()

for line in out.splitlines():
   if 'SABnzbd.py' in line:
      pid = int(line.split(None, 1)[0])
      os.kill(pid, signal.SIGKILL)
      xbmc.log('Audo: Shutting SickBeard down...', level=xbmc.LOGDEBUG)
   if 'SickBeard.py' in line:
      pid = int(line.split(None, 1)[0])
      os.kill(pid, signal.SIGKILL)
      xbmc.log('Audo: Shutting SickBeard down...', level=xbmc.LOGDEBUG)
   if 'CouchPotato.py' in line:
      pid = int(line.split(None, 1)[0])
      os.kill(pid, signal.SIGKILL)
      xbmc.log('Audo: Shutting CouchPotato down...', level=xbmc.LOGDEBUG)
   if 'Headphones.py' in line:
      pid = int(line.split(None, 1)[0])
      os.kill(pid, signal.SIGKILL)
      xbmc.log('Audo: Shutting Headphones down...', level=xbmc.LOGDEBUG)
