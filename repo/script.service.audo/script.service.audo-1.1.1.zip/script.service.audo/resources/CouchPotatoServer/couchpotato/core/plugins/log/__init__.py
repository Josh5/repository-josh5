from .main import Logging


def autoload():
    return Logging()
